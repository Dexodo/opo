const Discord = require('discord.js');
const fs = require('fs');
const client = new Discord.Client({ intents: 3276799 });
const {
  MessageEmbed,
  MessageActionRow,
  MessageButton,
  Modal,
  TextInputComponent,
} = require("discord.js");
const PREFIX = '!';
let contadorReseñas = 0;

// Función para leer el contador de reseñas desde el archivo
function leerContador() {
  try {
    const data = fs.readFileSync('contador.txt', 'utf8');
    contadorReseñas = parseInt(data.trim());
    console.log("Contador de reseñas cargado:", contadorReseñas);
  } catch (err) {
    console.error("Error al leer el archivo del contador:", err);
  }
}

// Función para guardar el contador de reseñas en el archivo
function guardarContador() {
  fs.writeFile('contador.txt', contadorReseñas.toString(), (err) => {
    if (err) {
      console.error("Error al guardar el contador:", err);
    } else {
      console.log("Contador de reseñas guardado:", contadorReseñas);
    }
  });
}

// Llamar a la función para cargar el contador al iniciar el bot
leerContador();

client.on("messageCreate", async message => {
  if (message.author.bot) return;
  
  if (message.content.startsWith(`${PREFIX}bouch`)) {
    const row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('reseñ')
          .setLabel('Dejar Referencia')
          .setEmoji('<:puntaje:1218408470353674280>')
          .setStyle('SUCCESS')
      );
      
    await message.channel.send({ content: '**<:pepeamor:1212082806159835231> ¿ Podrias dejarnos una referencia ? <:pepeamor:1212082806159835231> **\n\n* **Esto no toma mas de 1 minuto**\n* **Dale al boton y rellena los campos**', components: [row] });
  }
});

client.on("interactionCreate", async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId == "reseñ") {
      if (interaction.deferred || interaction.replied) {
        return;
      }
      const deposito = new Modal()
        .setTitle("Dejanos tu referencia")
        .setCustomId("reseños");

      const reseña = new TextInputComponent()
        .setCustomId("res")
        .setLabel(`Acá deja tu referencia`.substring(0, 45))
        .setMinLength(1)
        .setMaxLength(50)
        .setRequired(true)
        .setStyle("PARAGRAPH");

      const estrella = new TextInputComponent()
        .setCustomId("estre")
        .setLabel(`Indicanos el puntaje del servicio del 1 al 5`.substring(0, 45))
        .setMinLength(1)
        .setMaxLength(2)
        .setRequired(true)
        .setStyle("SHORT");

      const reseñas = new MessageActionRow().addComponents(reseña);
      const estrellas = new MessageActionRow().addComponents(estrella);
      deposito.addComponents(reseñas, estrellas);

      await interaction.showModal(deposito);
    }
  } else if (interaction.isModalSubmit()) {
    if (interaction.customId === "reseños") {
      reseñas = interaction.fields.getTextInputValue("res");
      estrellas = interaction.fields.getTextInputValue("estre");
      const user = interaction.user;
      const avatarURL = user.displayAvatarURL({ format: "png", dynamic: true });
      const username = user.username;

      const numEstrellas = parseInt(estrellas);
      if (isNaN(numEstrellas) || numEstrellas < 1 || numEstrellas > 5) {
        await interaction.reply({
          content: "No bug. Por favor, ingresa un número válido de estrellas (entre 1 y 5).",
          ephemeral: true,
        });
        return;
      }

      const estrellasEmoji = '<:puntaje:1218408470353674280>'.repeat(numEstrellas);
      contadorReseñas++;

      guardarContador();

      const embed = new MessageEmbed()
        .setAuthor(`Referencia #${contadorReseñas}`, (avatarURL))
        .setTitle(`Referencia de ${username}`)
        .setDescription(`# ${reseñas}`)
        .addField("**PUNTAJE:**", `${estrellasEmoji} [${estrellas}/5]`)
        .setColor("#ff25d5")
        .setFooter("Gracias por elegir a GG");

      const row = new MessageActionRow()
        .addComponents(
          new MessageButton()
            .setCustomId('reseñ')
            .setLabel('Deja Tu Referencia')
            .setEmoji('<:puntaje:1218408470353674280>')
            .setStyle('SUCCESS')
        );

      // Obteniendo el canal donde se ejecutó el comando !vouch
      const channel = interaction.channel;

      await interaction.reply({ content: "Referencia enviada en <#1124923036752166923>" });

      // Enviando el embed con el botón al canal específico
      const channelId = '1124923036752166923'; // Reemplaza 'ID_DEL_CANAL' con el ID del canal específico
      const specificChannel = await interaction.guild.channels.cache.get(channelId);

      if (!specificChannel) {
        console.error(`No se pudo encontrar el canal con ID ${channelId}`);
        return;
      }

      await specificChannel.send({ embeds: [embed], components: [row] });
    }
  }
});

client.login('');
